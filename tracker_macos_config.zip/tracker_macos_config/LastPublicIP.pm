###############################################################################
## OCSINVENTORY PLUGIN
## LAST PUBLIC IP
## Author: GBAF
################################################################################

use utf8;
use JSON;
use LWP::UserAgent;
use Encode qw(decode encode);
use HTML::Entities;
use Unicode::Normalize;

package Ocsinventory::Agent::Modules::LastPublicIP;

sub new {
 
   my $name="lastpublicip";
 
   my (undef,$context) = @_;
   my $self = {};
 
   $self->{logger} = new Ocsinventory::Logger ({
            config => $context->{config}
   });
 
   $self->{logger}->{header}="[$name]";
 
   $self->{context}=$context;
 
   $self->{structure}= {
                        name => $name,
                        start_handler => undef,
                        prolog_writer => undef,
                        prolog_reader => undef,
                        inventory_handler => $name."_inventory_handler",
                        end_handler => undef
   };
 
   bless $self;
}
  
sub lastpublicip_inventory_handler {
    
    my $self = shift;
    my $logger = $self->{logger};
    my $common = $self->{context}->{common};

    $logger->debug("lastpublicip_inventory_handler :)");

    $ua = LWP::UserAgent->new;

    my $req = HTTP::Request->new( GET => 'https://www.ipinfo.io/json' );
    $req->content_type('application/json');
    my $res = $ua->request($req);

    die $res->status_line unless $res->is_success;

    my $json = JSON->new->allow_nonref
        ->utf8->relaxed;

    my $myjson = $json->decode( $res->content );    

    my $ip = $myjson->{ip};
    my $city = Unicode::Normalize::NFKD( $myjson->{city} ); 
    my $org = Unicode::Normalize::NFKD( $myjson->{org} );
    $city =~ s/\p{NonspacingMark}//g;
    $org =~ s/\p{NonspacingMark}//g;

    $logger->debug($res->content);
    $logger->debug($myjson->{ip});
    $logger->debug($org);
    $logger->debug($city);

    push @{$common->{xmltags}->{LASTPUBLICIP}},
    {
        IP => [$ip],
        CITY => [$city],
        ORG => [$org],
    };
    }
 
1;