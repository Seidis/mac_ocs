#!/usr/bin/env bash

cp -f LastPublicIP.pm /Applications/OCSNG.app/Contents/Resources/lib/Ocsinventory/Agent/Modules/LastPublicIP.pm
cp -f cacert.pem /etc/ocsinventory-agent
cp -f modules.conf /etc/ocsinventory-agent
cp -f ocsinventory-agent.cfg /etc/ocsinventory-agent
